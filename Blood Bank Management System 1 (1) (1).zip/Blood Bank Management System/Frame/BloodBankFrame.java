package Frame;

import Entity.Donor;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeParseException;

public class BloodBankFrame extends JFrame implements MouseListener, ActionListener {
    Color c1, c2;
    Font f1, f2;
    JPanel panel;
    JLabel label1, label2, label3, label4, label5, label6, label7, label8, label9, label10, label11, label12, label13;
    JTextField tf1, tf2, tf3, tf4, tf5, tf6, tf7, tf8, tf9;
    JComboBox<String> cb1, cb2;
    JRadioButton rb1, rb2;
    ButtonGroup bg;
    JButton bt1, bt2, bt3, bt4, bt5;
    DefaultTableModel model;
    JTable table;
    JScrollPane scroll;

    static final String DATA_DIR = "data";
    static final String DATA_FILE = DATA_DIR + "/donors.txt";

    public BloodBankFrame() {
        super("Blood-Bank Donor Management");
        setBounds(200, 100, 1160, 605);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        panel = new JPanel();
        c2 = new Color(139, 0, 0); 
        panel.setBackground(c2);
        panel.setLayout(null);
        f1 = new Font("Cambria", Font.BOLD, 28);
        f2 = new Font("Cambria", Font.PLAIN, 16);

        // Title
        label1 = new JLabel("Blood-Bank Donor Management");
        c1 = Color.WHITE;
        label1.setForeground(c1);
        label1.setFont(f1);
        label1.setBounds(360, 10, 600, 40);
        panel.add(label1);

        // Donor ID
        label2 = new JLabel("Donor ID:");
        label2.setFont(f2); 
		label2.setForeground(c1);
		label2.setBounds(635, 70, 150, 25);
        panel.add(label2);
        tf1 = new JTextField(); 
		tf1.setFont(f2);
		tf1.setBounds(720, 70, 140, 25);
        tf1.setBackground(c2); 
		tf1.setForeground(c1);
        panel.add(tf1);

        // Name
        label3 = new JLabel("Name:");
		label3.setFont(f2); 
		label3.setForeground(c1); 
		label3.setBounds(20, 70, 150, 25);
        panel.add(label3);
        tf2 = new JTextField();
		tf2.setFont(f2);
		tf2.setBounds(130, 70, 260, 25);
		tf2.setBackground(c2); 
		tf2.setForeground(c1);
        panel.add(tf2);

        // Age
        label13 = new JLabel("Age:");
		label13.setFont(f2);
		label13.setForeground(c1);
		label13.setBounds(20, 110, 150, 25);
        panel.add(label13);
        tf3 = new JTextField();
		tf3.setFont(f2); 
		tf3.setBounds(130, 110, 60, 25); 
		tf3.setEditable(false);
		tf3.setBackground(c2);
		tf3.setForeground(c1);
        panel.add(tf3);

        // DOB
        label4 = new JLabel("Date of Birth (YYYY-MM-DD):");
		label4.setFont(f2);
		label4.setForeground(c1);
		label4.setBounds(330, 110, 220, 25);
        panel.add(label4);
        tf4 = new JTextField(); 
		tf4.setFont(f2); 
		tf4.setBounds(550, 110, 140, 25);
		tf4.setBackground(c2); 
		tf4.setForeground(c1);
        panel.add(tf4);

        // Gender
        label5 = new JLabel("Gender:");
		label5.setFont(f2); 
		label5.setForeground(c1); 
		label5.setBounds(830, 110, 150, 25);
        panel.add(label5);
        rb1 = new JRadioButton("Male");
		rb1.setFont(f2); rb1.setBackground(c2);
		rb1.setForeground(c1);
		rb1.setBounds(920, 110, 60, 25); 
		panel.add(rb1);
        rb2 = new JRadioButton("Female"); 
		rb2.setFont(f2);
		rb2.setBackground(c2); 
		rb2.setForeground(c1);
		rb2.setBounds(1010, 110, 80, 25);
		panel.add(rb2);
        bg = new ButtonGroup();
		bg.add(rb1);
		bg.add(rb2);

        // Blood Group
        label6 = new JLabel("Blood Group:"); 
		label6.setFont(f2); 
		label6.setForeground(c1); 
		label6.setBounds(20, 150, 150, 25);
		panel.add(label6);
        cb1 = new JComboBox<>(new String[]{"Select Blood Group","A+","A-","B+","B-","AB+","AB-","O+","O-"});
		cb1.setFont(f2); 
		cb1.setBounds(130,150,170,25);
		panel.add(cb1);

        // Height & Weight
        label7 = new JLabel("Height (cm):");
		label7.setFont(f2);
		label7.setForeground(c1);
		label7.setBounds(450,150,150,25);
		panel.add(label7);
        tf5 = new JTextField();
		tf5.setFont(f2);
		tf5.setBounds(550,150,100,25);
		tf5.setBackground(c2);
		tf5.setForeground(c1);
		panel.add(tf5);

        label8 = new JLabel("Weight (kg):");
		label8.setFont(f2);
		label8.setForeground(c1); 
		label8.setBounds(830,150,150,25);
		panel.add(label8);
        tf6 = new JTextField();
		tf6.setFont(f2); 
		tf6.setBounds(930,150,100,25); 
		tf6.setBackground(c2); 
		tf6.setForeground(c1); 
		panel.add(tf6);

        // Last Donation
        label9 = new JLabel("Last Donation(YYYY-MM-DD):"); 
		label9.setFont(f2); 
		label9.setForeground(c1); 
		label9.setBounds(20,190,300,25); 
		panel.add(label9);
        tf7 = new JTextField(); 
		tf7.setFont(f2); 
		tf7.setBounds(250,190,140,25); 
		tf7.setBackground(c2); 
		tf7.setForeground(c1);
		panel.add(tf7);

        // Contact & Address
        label10 = new JLabel("Contact Number:"); 
		label10.setFont(f2); 
		label10.setForeground(c1);
		label10.setBounds(585,190,150,25);
		panel.add(label10);
        tf8 = new JTextField(); 
		tf8.setFont(f2);
		tf8.setBounds(720,190,140,25);
		tf8.setBackground(c2);
		tf8.setForeground(c1);
		panel.add(tf8);

        label11 = new JLabel("Address(Area - District - Post Code):"); 
		label11.setFont(f2); 
		label11.setForeground(c1);
		label11.setBounds(20,230,300,25);
		panel.add(label11);
        tf9 = new JTextField();
		tf9.setFont(f2);
		tf9.setBounds(290,230,260,25);
		tf9.setBackground(c2);
		tf9.setForeground(c1); 
		panel.add(tf9);

        // Buttons
        bt1 = new JButton("Add Donor");
		bt1.setFont(f2);
		bt1.setBackground(Color.WHITE);
		bt1.setBounds(20,285,120,25); 
		bt1.addActionListener(this);
		bt1.addMouseListener(this);
		panel.add(bt1);
		
        bt2 = new JButton("Delete Donor"); 
		bt2.setFont(f2); 
		bt2.setBackground(Color.WHITE); 
		bt2.setBounds(190,285,130,25);
		bt2.addActionListener(this); 
		bt2.addMouseListener(this);
		panel.add(bt2);
		
        bt3 = new JButton("Update Last Donation");
		bt3.setFont(f2); bt3.setBackground(Color.WHITE); 
		bt3.setBounds(365,285,200,25); 
		bt3.addActionListener(this);
		bt3.addMouseListener(this);
		panel.add(bt3);

        cb2 = new JComboBox<>(new String[]{"Select Blood Group","A+","A-","B+","B-","AB+","AB-","O+","O-"}); 
		cb2.setFont(f2); 
		cb2.setBounds(640,285,170,25); 
		panel.add(cb2);
        bt4 = new JButton("Search"); 
		bt4.setFont(f2); 
		bt4.setBackground(Color.WHITE); 
		bt4.setBounds(850,285,100,25); 
		bt4.addActionListener(this);
		bt4.addMouseListener(this);
		panel.add(bt4);

        bt5 = new JButton("Exit");
		bt5.setFont(f2); 
		bt5.setBackground(Color.WHITE);
		bt5.setBounds(1020,285,100,25); 
		bt5.addActionListener(this); 
		panel.add(bt5);

        // Table
        model = new DefaultTableModel();
        model.setColumnIdentifiers(new Object[]{"ID","Name","Age","Gender","Date of Birth","Blood Group","Height","Weight","Last Donation","Contact","Address","Donation Count"});
        table = new JTable(model);
        table.addMouseListener(this);
        scroll = new JScrollPane(table); 
		scroll.setBounds(20,330,1100,200);
		panel.add(scroll);

        // Image (background)
        ImageIcon img = new ImageIcon("Image/Blood.png");
        Image scaledImg = img.getImage().getScaledInstance(1140,550,Image.SCALE_SMOOTH);
        label12 = new JLabel(new ImageIcon(scaledImg));
		label12.setBounds(0,0,1140,550);
		panel.add(label12);

        setContentPane(panel);

        initializeDataFile();
        loadFromFile();

        setVisible(true);
    }

    // Create file if not exist
    public void initializeDataFile() {
        try {
            Files.createDirectories(Paths.get(DATA_DIR));
            File f = new File(DATA_FILE);
            if (!f.exists()) f.createNewFile();
        } catch(IOException e) { JOptionPane.showMessageDialog(this,"Error initializing data file."); }
    }

    // Load data from file
    public void loadFromFile() {
        model.setRowCount(0);
        try (BufferedReader br = new BufferedReader(new FileReader(DATA_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                model.addRow(data);
            }
        } catch(IOException e){ JOptionPane.showMessageDialog(this,"Error loading data.");}
    }

    // Save all data to file
    public void saveAllToFile() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(DATA_FILE))) {
            for(int i=0;i<model.getRowCount();i++){
                for(int j=0;j<model.getColumnCount();j++){
                    bw.write(model.getValueAt(i,j).toString());
                    if(j<model.getColumnCount()-1) bw.write(",");
                }
                bw.newLine();
            }
        } catch(IOException e){ JOptionPane.showMessageDialog(this,"Error saving data.");}
    }

    // Calculate age from DOB
    public int calculateAge(String dob) {
        try {
            LocalDate birth = LocalDate.parse(dob);
            return Period.between(birth, LocalDate.now()).getYears();
        } catch(DateTimeParseException e){ return -1; }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == bt1) { // Add donor
            String id=tf1.getText().trim(), name=tf2.getText().trim(), dob=tf4.getText().trim();
            String gender = rb1.isSelected()?"Male":rb2.isSelected()?"Female":"";
            String blood = cb1.getSelectedItem().toString();
            String height=tf5.getText().trim(), weight=tf6.getText().trim();
            String lastDonation=tf7.getText().trim(), contact=tf8.getText().trim(), address=tf9.getText().trim();
            int age=calculateAge(dob); tf3.setText(String.valueOf(age));

            if(id.isEmpty()||name.isEmpty()||dob.isEmpty()||gender.isEmpty()||blood.equals("Select Blood Group")){
                JOptionPane.showMessageDialog(this,"Please fill all required fields."); return;
            }

            model.addRow(new Object[]{id,name,age,gender,dob,blood,height,weight,lastDonation,contact,address,"0"});
            saveAllToFile();
            JOptionPane.showMessageDialog(this,"Donor added successfully.");
        }
        else if(e.getSource() == bt2) { // Delete
            int row = table.getSelectedRow();
            if(row>=0){ model.removeRow(row); saveAllToFile(); JOptionPane.showMessageDialog(this,"Donor deleted."); }
            else JOptionPane.showMessageDialog(this,"Select a donor to delete.");
        }
        else if(e.getSource() == bt3) { // Update last donation
            int row = table.getSelectedRow();
            if(row>=0){
                String newDate = JOptionPane.showInputDialog(this,"Enter new donation date (YYYY-MM-DD):");
                if(newDate!=null && !newDate.trim().isEmpty()){
                    table.setValueAt(newDate,row,8);
                    int count = Integer.parseInt(table.getValueAt(row,11).toString())+1;
                    table.setValueAt(count,row,11);
                    saveAllToFile();
                    JOptionPane.showMessageDialog(this,"Donation updated.");
                }
            } else JOptionPane.showMessageDialog(this,"Select a donor to update.");
        }
        else if(e.getSource() == bt4) { // Search by blood
            String group = cb2.getSelectedItem().toString();
            if(group.equals("Select Blood Group")) { JOptionPane.showMessageDialog(this,"Select a blood group."); return; }
            model.setRowCount(0);
            try(BufferedReader br=new BufferedReader(new FileReader(DATA_FILE))){
                String line;
                while((line=br.readLine())!=null){
                    String[] data=line.split(",");
                    if(data[5].equals(group)) model.addRow(data);
                }
            } catch(IOException ex){ JOptionPane.showMessageDialog(this,"Error searching data.");}
        }
        else if(e.getSource() == bt5) { System.exit(0); }
    }

    // Table click
    @Override
    public void mouseClicked(MouseEvent e){
        int row = table.getSelectedRow();
        if(row>=0){
            tf1.setText(model.getValueAt(row,0).toString()); 
			tf2.setText(model.getValueAt(row,1).toString());
            tf3.setText(model.getValueAt(row,2).toString());
			tf4.setText(model.getValueAt(row,4).toString());
            String gender=model.getValueAt(row,3).toString();
            if(gender.equals("Male")) rb1.setSelected(true); 
			else rb2.setSelected(true);
            cb1.setSelectedItem(model.getValueAt(row,5).toString());
            tf5.setText(model.getValueAt(row,6).toString());
			tf6.setText(model.getValueAt(row,7).toString());
            tf7.setText(model.getValueAt(row,8).toString());
			tf8.setText(model.getValueAt(row,9).toString());
            tf9.setText(model.getValueAt(row,10).toString());
        }
    }

   @Override
public void mouseEntered(MouseEvent e){
    if(e.getSource()==bt1){ bt1.setBackground(Color.RED);
                       	bt1.setForeground(Color.WHITE); }
    if(e.getSource()==bt2){ bt2.setBackground(Color.RED); 
	                    bt2.setForeground(Color.WHITE); }
    if(e.getSource()==bt3){ bt3.setBackground(Color.RED); 
	                    bt3.setForeground(Color.WHITE); }
    if(e.getSource()==bt4){ bt4.setBackground(Color.RED); 
	                    bt4.setForeground(Color.WHITE); }
    if(e.getSource()==bt5){ bt5.setBackground(Color.RED); 
	                    bt5.setForeground(Color.WHITE); }
}

@Override
public void mouseExited(MouseEvent e){
    if(e.getSource()==bt1){ bt1.setBackground(Color.WHITE);
                        	bt1.setForeground(Color.BLACK); }
    if(e.getSource()==bt2){ bt2.setBackground(Color.WHITE);
                         	bt2.setForeground(Color.BLACK); }
    if(e.getSource()==bt3){ bt3.setBackground(Color.WHITE); 
	                        bt3.setForeground(Color.BLACK); }
    if(e.getSource()==bt4){ bt4.setBackground(Color.WHITE); 
	                        bt4.setForeground(Color.BLACK); }
    if(e.getSource()==bt5){ bt5.setBackground(Color.WHITE); 
	                        bt5.setForeground(Color.BLACK); }
}


    @Override public void mousePressed(MouseEvent e){}
    @Override public void mouseReleased(MouseEvent e){}
    
}
