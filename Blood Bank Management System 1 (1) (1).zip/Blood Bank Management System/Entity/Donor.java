package Entity;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeParseException;

public class Donor {
    private String donorId;
    private String name;
    private String dateOfBirth; // YYYY-MM-DD
    private String gender;
    private String bloodGroup;
    private double height; // cm
    private double weight; // kg
    private String lastDonationDate; // YYYY-MM-DD
    private String contactNumber;
    private String address;
    private int donationCount;

    public Donor(String donorId, String name, String dateOfBirth, String gender, String bloodGroup,
                 double height, double weight, String lastDonationDate, String contactNumber,
                 String address, int donationCount) {
        this.donorId = donorId;
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.gender = gender;
        this.bloodGroup = bloodGroup;
        this.height = height;
        this.weight = weight;
        this.lastDonationDate = lastDonationDate;
        this.contactNumber = contactNumber;
        this.address = address;
        this.donationCount = donationCount;
    }

    // Getters
    public String getDonorId() { return donorId; }
    public String getName() { return name; }
    public String getDateOfBirth() { return dateOfBirth; }
    public String getGender() { return gender; }
    public String getBloodGroup() { return bloodGroup; }
    public double getHeight() { return height; }
    public double getWeight() { return weight; }
    public String getLastDonationDate() { return lastDonationDate; }
    public String getContactNumber() { return contactNumber; }
    public String getAddress() { return address; }
    public int getDonationCount() { return donationCount; }

    // Setters
    public void setLastDonationDate(String lastDonationDate) { this.lastDonationDate = lastDonationDate; }
    public void incrementDonationCount() { this.donationCount++; }

    // Calculate age dynamically from DOB
    public int getAge() {
        try {
            LocalDate dob = LocalDate.parse(dateOfBirth);
            return Period.between(dob, LocalDate.now()).getYears();
        } catch (DateTimeParseException e) {
            return -1;
        }
    }

    @Override
    public String toString() {
        // Save age in file as required
        return donorId + "," + name + "," + getAge() + "," + gender + "," + dateOfBirth + "," +
               bloodGroup + "," + height + "," + weight + "," + lastDonationDate + "," +
               contactNumber + "," + address + "," + donationCount;
    }
}
